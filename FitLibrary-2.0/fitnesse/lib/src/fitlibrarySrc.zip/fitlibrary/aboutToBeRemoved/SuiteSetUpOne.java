package fitlibrary.aboutToBeRemoved;
import fitlibrary.DoFixture;


public class SuiteSetUpOne extends DoFixture {
	//
}
