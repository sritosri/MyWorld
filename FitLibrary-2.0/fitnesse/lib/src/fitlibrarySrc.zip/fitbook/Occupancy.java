/*
 * @author Rick Mugridge 6/12/2003
 *
 * Copyright (c) 2003 Rick Mugridge, University of Auckland, NZ
 * Released under the terms of the GNU General Public License version 2 or later.
 *
 */
package fitbook;

/**
  *
*/
public class Occupancy { //COPY:ALL
	public String room, user; //COPY:ALL
	//COPY:ALL
	public Occupancy(String roomName, String userName) { //COPY:ALL
		this.room = roomName; //COPY:ALL
		this.user = userName; //COPY:ALL
	} //COPY:ALL
} //COPY:ALL
